# CSS-only underline hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/t_afif/pen/bGQOaEb](https://codepen.io/t_afif/pen/bGQOaEb).

